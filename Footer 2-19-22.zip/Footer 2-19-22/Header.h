/*
Author: MF

Date: 2/19/2022

Purpose: Write a header file that stores structs and function headers
*/
#ifndef Header_h
#define Header_h

#define _CRT_SECURE_NO_WARNINGS


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

typedef struct business
{
	char name[200];

	char foodType[200];

	char location[200];

	int rating;

} Business;

typedef struct node
{
	Business data;

	struct node* next;

	struct node* prev;

} Node;

#endif