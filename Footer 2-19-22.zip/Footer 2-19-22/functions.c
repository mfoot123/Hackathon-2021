/*
Author: MF

Date: 2/19/2022

Purpose: Write functions that allow the user to manipuate the digital music collection
*/
#include "Header.h"

void printMenu()
{
	printf("(1)   load\n");
	printf("(2)   display\n");
	printf("(3)   insert\n");
	printf("(4)   delete\n");
	printf("(5)   edit\n");
	printf("(6)   rate\n");
	printf("(7)   sort by rating\n");
	printf("(8)   exit\n");
}

int get_option(void)
{
	int option = 0;

	scanf("%d", &option);

	return option;
}

int print_and_validate(option)
{
	do
	{
		printMenu();
		option = get_option();
	} while ((0 > option) && (option > 12));
	{
		system("cls");
		return option;
	}
}

Node* newNode(Business value)
{
	Node* result = (Node*)malloc(sizeof(Node));

	//Duration test = { value.length.minutes, value.length.seconds };

	result->prev = NULL;
	result->next = NULL;

	strcpy(result->data.name, value.name);
	strcpy(result->data.foodType, value.foodType);
	strcpy(result->data.location, value.location);
	result->data.rating = value.rating;

	return result;
}

int insertAtHead(Node** pHead, Business value)
{

	Node* temp = newNode(value);
	int success = 0;
	if (*pHead != NULL)
	{
		(*pHead)->prev = temp;
		temp->next = *pHead;
		success = 1;
	}
	*pHead = temp;
	temp->prev = NULL;
	return success;
}

void printData(Node* pHead)
{
	Node* temp = pHead;
	while (temp != NULL)
	{
		printf("Artist: %s\n", temp->data.name);
		printf("Album title: % s\n", temp->data.foodType);
		printf("Song title: %s\n", temp->data.location);
		printf("Rating: %d\n", temp->data.rating);
		temp = temp->next;
	}
	printf("\n");
}

Node* loadSongs(FILE* infile, Node** pHead) {

	Business data = { '\0' };

	// declare a variable that stores line data
	char line[100];

	while (fgets(line, 100, infile) != NULL)
	{
		//puts(line);
		// strtok () to parse a line; .csv file
		int index = 0;

		// take the artist name
		strcpy(data.name, strtok(line, ","));
		//printf("Artist: %s\n", data[lineCount].artist);

		strcpy(data.foodType, strtok(NULL, ","));
		//printf("Album title: % s\n", data[lineCount].albumTitle);

		strcpy(data.location, strtok(NULL, ","));
		//printf("Song title: %s\n", data[lineCount].songTitle);

		data.rating = atoi(strtok(NULL, ","));
		//printf("Rating: %d\n", data[lineCount].rating);

		// print the line count
		//printf("%d\n", lineCount);

		insertAtHead(pHead, data);

	}
	//printData(pHead);
	return *pHead;
}

void printArtistData(Node* pHead, char* name)
{
	Node* temp = pHead;
	while (temp != NULL)
	{
		if (strcmp(temp->data.name, name) == 0)
		{
			printf("Artist: %s\n", temp->data.name);
			printf("Album title: % s\n", temp->data.foodType);
			printf("Song title: %s\n", temp->data.location);
			printf("Rating: %d\n", temp->data.rating);
		}
		temp = temp->next;
	}
	printf("\n");
}

void changeRating(Node* pHead, char* name)
{
	Node* temp = pHead;
	int tempRating = NULL;

	while (temp != NULL)
	{
		if (strcmp(temp->data.name, name) == 0)
		{
			printf("What new rating would you like to give?\n");
			scanf("%d", &tempRating);
			temp->data.rating = tempRating;
		}
		temp = temp->next;
	}
}

void printDataOut(Node* pHead, FILE* outfile)
{
	//outfile = fopen("MusicPlaylist.csv", "w");
	Node* temp = pHead;
	while (temp != NULL)
	{
		fprintf(outfile, "%s,", temp->data.name);
		fprintf(outfile, "%s,", temp->data.foodType);
		fprintf(outfile, "%s,", temp->data.location);
		fprintf(outfile, "%d\n", temp->data.rating);
		temp = temp->next;
	}
	printf("\n");
}

void changeData(Node* pHead, char* name, char* item)
{
	Node* temp = pHead;
	int tempRating = -1;
	char tempString[30];
	int count = 0;

	while (temp != NULL)
	{
		if (strcmp(temp->data.name, name) == 0)
		{
			if (strcmp("Artist", item) == 0)
			{
				printf("What new name would you like to give?\n");
				scanf("%s", tempString);
				strcpy(temp->data.name, tempString);
			}
			if (strcmp("Album title", item) == 0)
			{
				printf("What new food type would you like to give?\n");
				scanf("%s", tempString);
				strcpy(temp->data.foodType, tempString);
			}
			if (strcmp("Song title", item) == 0)
			{
				printf("What new location would you like to give?\n");
				scanf("%s", tempString);
				strcpy(temp->data.location, tempString);
			}
			if (strcmp("rating", item) == 0)
			{
				printf("What new rating would you like to give?\n");
				scanf("%d", tempRating);
				temp->data.rating = tempRating;
			}
		}
		temp = temp->next;
	}
}


int getInfo(Node** pHead) {

	Business data = { "", "", "", 0 };
	int success = 0;

	printf("Who is the artist?\n");
	scanf("%s", data.name);
	printf("What is the albums title\n");
	scanf("%s", data.foodType);
	printf("What is the songs title\n");
	scanf("%s", data.location);
	printf("What is the genre?\n");
	printf("What is the rating?\n");
	scanf("%d", &data.rating);
	if (data.rating > 5)
	{
		data.rating = 5;;
	}

	if (insertAtHead(pHead, data) == 1)
	{
		success = 1;
	}

	return success;
}

int deleteBusiness(Node** pHead, char* name)
{
	Node* temp = *pHead;
	int success = 0;
	/*Node* prev = temp->prev;
	Node* next = temp->next;*/
	while (temp != NULL)
	{
		if (strcmp(temp->data.name, name) == 0)
		{
			if (temp->prev != NULL)
			{
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
			}
			if (temp->prev == NULL)  //removing first node
			{
				*pHead = temp->next;
				temp->next->prev = NULL;
			}
			if (temp->next == NULL)  //removing last node
			{
				temp->prev->next = NULL;
			}
			free(temp);
			success = 1;
			//temp = NULL;
			return success;
		}
		temp = temp->next;
	}
	//return *pHead;
	return success;
}

int detNumBusiness(Node** pHead)
{
	Node* temp = *pHead;
	int x = 0;
	while (temp->next != NULL)
	{
		++x;
		temp = temp->next;
	}
	return x;
}

Node* sortRating(Node** pHead, int numOfBusiness) {

	Business temp = { "" };
	Node* pCur = *pHead;

	for (int i = 0; i < numOfBusiness; ++i) // controls # of passes
	{
		for (pCur = *pHead; pCur->next != NULL; pCur = pCur->next) // control walking through array - incrementing index
		{
			if (pCur->data.rating > pCur->next->data.rating)
			{
				temp = pCur->data;
				pCur->data = pCur->next->data;
				pCur->next->data = temp;
			}
		}
	}
}

