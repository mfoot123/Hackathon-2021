#include "Header.h"

int main(void)
{
	// open the file to read from
	FILE* infile;
	// open the file to write to
	FILE* outfile;

	// declare struct array that stores data values

	// intialize head pointer
	Node* pHead = NULL;
	// create a temporary node
	Node* temp;

	// declare variable that counts number of lines
	int lineCount = 0;
	// create a variable that represents a users option
	int option;
	// create a string for a songs name
	char nameBusiness[30];

	char* songs[15];

	char list[15];
	// create a string for the user to input what item they want to change
	char item[30];

	srand((unsigned int)time(NULL));

	// print the menu
	printMenu();
	do
	{
		system("cls");
		option = print_and_validate();
		switch (option)
		{
		case 1:
			// open the file for reading
			infile = fopen("business.txt", "r");
			// if theres things in the file
			if (infile != NULL)
			{
				temp = pHead;
				pHead = loadSongs(infile, &pHead);
				system("Pause");
			}
			fclose(infile);
			break;

		case 2:
				printData(pHead);
				system("Pause");
			break;

		case 3:

			getInfo(&pHead);
			system("Pause");
			break;

		case 4:
			printf("Which business would you like to find?\n");
			gets(nameBusiness);
			gets(nameBusiness);
			deleteBusiness(&pHead, nameBusiness);
			system("Pause");
			break;

		case 5:
			printf("Which business would you like to find?\n");
			gets(nameBusiness);
			gets(nameBusiness);
			changeData(pHead, nameBusiness, item);
			system("Pause");
			break;

		case 6:
			printf("Which business would you like to find?\n");
			gets(nameBusiness);
			gets(nameBusiness);
			changeRating(pHead, nameBusiness);
			system("Pause");
			break;

		case 7:
			printf("sorting\n");
			int numOfBusiness = detNumBusiness(&pHead);
			if (sortRating(&pHead, numOfBusiness) == 1)
			{
				printf("Sorted!\n");
			}

		case 8:
			printf("Goodbye!\n");
			break;

		}
	} while (option != 8);

	return 0;
}